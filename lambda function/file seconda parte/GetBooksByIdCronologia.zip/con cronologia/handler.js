const connect_to_db = require('./db');
const User = require('./Talk');
const request = require('request');

module.exports.get_related_books = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    let body = {};
    if (event.body) {
        body = JSON.parse(event.body);
    }
    
    // Set default values
    if (!body.id) {
        if(event.id) {
            body.id = event.id;
        } else {
            callback(null, {
                statusCode: 500,
                headers: { 'Content-Type': 'text/plain' },
                body: 'Could not fetch the user. ID is missing.'
            })
            return; // Importante aggiungere il return qui per evitare che il codice continui
        }
    }

    // Connect to MongoDB
    connect_to_db().then(() => {
        console.log('=> Searching for user');

        // Find user by ID
        User.findOne({ _id: body.id })
            .then(user => {
                if (!user) {
                    throw new Error('User not found');
                }
                 console.log('User:', JSON.stringify(user, null, 2).substring(0, 1000));
                // Extract tags and counts from user document
                //console.log('Controllo i user :', user);

               
                const id = user._id;
                console.log('All Tags Info:', id);
                
                const allTagsInfo = user.all_tags_info;
                console.log("All Tags Info:", JSON.stringify(user.allTagsInfo));
                
                const firstTagInfo = user.all_tags_info.tag;
                console.log('First Tag Info:', firstTagInfo);
                /*PRIMA PROVA
                const tagsWithCounts = user(tagInfo => ({
                    tag: tagInfo.tag,
                    count: tagInfo.tag_count
                }));
                */
                /*
                //SECONDO TENTATIVO
                
                    // Itera su user per ottenere i tag e i relativi conteggi
                const tagsWithCounts = Object.keys(user).map(tags => ({
                    tag: tags.tag,
                    count: tags.tag_count
                }));
                */
                /*
                //TERZO TENTATIVO, RISULTA TUTTO UNDEFINED
                const tagsWithCounts = [];

                // Itera su ogni oggetto all'interno di user
                for (const tagInfo of Object.values(user)) {
                    // Estrai il tag e il tag_count da ogni oggetto
                    console.log('TagsInfo trovato:', tagInfo);
                    const tag = tagInfo.tag;
                    const count = tagInfo.tag_count;
                    console.log('Tags trovato:', tag);
                    console.log('Tags_count trovato:', count);
                    // Aggiungi il tag e il relativo conteggio all'array
                    tagsWithCounts.push({ tag, count });
                }
                console.log('Tags with counts:', tagsWithCounts);
                */
                //CHAT GTP 4
                // Funzione lambda per estrapolare 'tag' e 'tag_count'
                const tags = user.tags; // Cambia 'tags' con la proprietà corretta se differente
                console.log('Controllo i tag dell\'utente:', tags);

                // Estrapola 'tag' e 'tag_count'
                const tagsWithCounts = tags.map(item => ({ tag: item.tag, tag_count: item.tag_count }));

                console.log("tagsWithCounts:", tagsWithCounts);

                console.log("tagsWithCounts:", tagsWithCounts);
                 
                // Ordina i tag per conteggio in ordine decrescente
                const sortedTags = tagsWithCounts.sort((a, b) => b.count - a.count);
                
                // Prendi i primi 10 tag (o meno se ci sono meno di 10 tag)
                const topTags = sortedTags.slice(0, Math.min(10, sortedTags.length)).map(tagInfo => tagInfo.tag);
                
                console.log('Calling Google Books API for tag:', topTags);
                // Query Google Books API for each top tag
                const booksPromises = topTags.map(tag => {
                    const url = `https://www.googleapis.com/books/v1/volumes?q=${tag}&maxResults=1`;
                    return new Promise((resolve, reject) => {
                        request(url, (error, response, body) => {
                            if (error) {
                                reject(error);
                            } else if (response.statusCode !== 200) {
                                reject(new Error(`Google Books API returned status code ${response.statusCode}`));
                            } else {
                                const data = JSON.parse(body);
                                if (data && data.items && data.items.length > 0) {
                                    resolve({
                                        title: data.items[0].volumeInfo.title,
                                        authors: data.items[0].volumeInfo.authors,
                                        description: data.items[0].volumeInfo.description
                                    });
                                } else {
                                    // If no books found for the tag, resolve with null
                                    resolve(null);
                                }
                            }
                        });
                    });
                });

                // Wait for all requests to Google Books API to complete
                Promise.all(booksPromises)
                    .then(books => {
                        // Filter out null values (tags with no associated books)
                        const filteredBooks = books.filter(book => book !== null);
                        
                        callback(null, {
                            statusCode: 200,
                            body: JSON.stringify({ books: filteredBooks })
                        });
                    })
                    .catch(err => {
                        throw new Error(`Error querying Google Books API: ${err.message}`);
                    });
            })
            .catch(err => {
                callback(null, {
                    statusCode: 404,
                    headers: { 'Content-Type': 'text/plain' },
                    body: err.message
                });
            });
    });
};
